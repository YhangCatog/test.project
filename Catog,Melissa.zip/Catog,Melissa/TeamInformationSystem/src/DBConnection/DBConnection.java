/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package DBConnection;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author User
 */
public class DBConnection {
public static  Connection connection;

    public static void databaseConnection() {
        try {
            if (connection == null || connection.isClosed()) {
                String databaseDriver = "com.mysql.jdbc.Driver";
                String connectionURL = "jdbc:mysql://localhost:3306/teaminformationsystem";
                String databaseUsername = "root";
                String databasePassword = "root";

                Class.forName(databaseDriver);
                connection = DriverManager.getConnection(connectionURL,
                        databaseUsername, databasePassword);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}


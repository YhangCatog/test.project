/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Team;

import DBConnection.DBConnection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.JOptionPane;

/**
 *
 * @author User
 */
public class Team {

    private int id;
    private String TeamName;
    private String SportsName;
    private String CoachName;
    private int NumberOfPlayers;
    private String SchoolName;

    public Team() {
    }

    public void select() {
        try {
            Vector row = new Vector();
            row.setSize(0);

            DBConnection.databaseConnection();

            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("select id,TeamName,SportsName,CoachName,NumberOfPlayers,SchoolName from team");
            ResultSet resultSet = preparedStatement.executeQuery();
            while (resultSet.next()) {
                int idl = resultSet.getInt("id");
                String teamnamel = resultSet.getString("TeamName");
                String sportsnamel = resultSet.getString("SportsName");
                String coachname = resultSet.getString("CoachName");
                int numberofplayers = resultSet.getInt("NumberOfPlayers");
                String schoolnamel = resultSet.getString("SchoolName");
                Vector column = new Vector();
                column.add(idl);
                column.add(teamnamel);
                column.add(sportsnamel);
                column.add(coachname);
                column.add(numberofplayers);
                column.add(schoolnamel);
                row.add(column);
            }
            resultSet.close();
            preparedStatement.close();

            for (int i = 0; i < row.size(); i++) {
                System.out.println(row.get(i));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void insert() {
        try {
            DBConnection.databaseConnection();

            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("insert into Team(id,TeamName,SportsName,CoachName,NumberOfPlayers,SchoolName) values (?,?,?,?,?,?)");
            preparedStatement.setInt(1, getId());
            preparedStatement.setString(2, getTeamName());
            preparedStatement.setString(3, getSportsName());
            preparedStatement.setString(4, getCoachName());
            preparedStatement.setInt(5, getNumberOfPlayers());
            preparedStatement.setString(6, getSchoolName());

            preparedStatement.execute();

            preparedStatement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update() {
        try {
            DBConnection.databaseConnection();
            PreparedStatement preparedStatement = DBConnection.connection.prepareStatement("update team set TeamName=?,SportsName=?,CoachName=?,NumberOfPlayers=?,SchoolName=? where id = ?");

            preparedStatement.setString(1, getTeamName());
            preparedStatement.setString(2, getSportsName());
            preparedStatement.setString(3, getCoachName());
            preparedStatement.setInt(4, getNumberOfPlayers());
            preparedStatement.setString(5, getSchoolName());
            preparedStatement.setInt(6, getId());
            preparedStatement.execute();
            preparedStatement.close();

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void delete() {
        try {
            DBConnection.databaseConnection();
            PreparedStatement statement = DBConnection.connection.prepareStatement("delete from  team"
                    + "where id = ?");
            statement.setInt(1, getId());
            statement.execute();
            statement.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the TeamName
     */
    public String getTeamName() {
        return TeamName;
    }

    /**
     * @param TeamName the TeamName to set
     */
    public void setTeamName(String TeamName) {
        this.TeamName = TeamName;
    }

    /**
     * @return the SportsName
     */
    public String getSportsName() {
        return SportsName;
    }

    /**
     * @param SportsName the SportsName to set
     */
    public void setSportsName(String SportsName) {
        this.SportsName = SportsName;
    }

    /**
     * @return the CoachName
     */
    public String getCoachName() {
        return CoachName;
    }

    /**
     * @param CoachName the CoachName to set
     */
    public void setCoachName(String CoachName) {
        this.CoachName = CoachName;
    }

    /**
     * @return the NumberOfPlayers
     */
    public int getNumberOfPlayers() {
        return NumberOfPlayers;
    }

    /**
     * @param NumberOfPlayers the NumberOfPlayers to set
     */
    public void setNumberOfPlayers(int NumberOfPlayers) {
        this.NumberOfPlayers = NumberOfPlayers;
    }

    /**
     * @return the SchoolName
     */
    public String getSchoolName() {
        return SchoolName;
    }

    /**
     * @param SchoolName the SchoolName to set
     */
    public void setSchoolName(String SchoolName) {
        this.SchoolName = SchoolName;
    }
}
